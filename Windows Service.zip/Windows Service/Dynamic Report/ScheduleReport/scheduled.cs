﻿using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI;
using System.Web.UI.WebControls;
using Oracle.DataAccess.Client;
using System.Xml;

public class scheduled
{
    private GridView gridDetails = new GridView();
    string currentTime { get; set; }
    private Random random = new Random();
    public string saveLocation { get; set; }
    public string queryBuilder { get; set; }
    public string emailList { get; set; }
    public string recurrence { get; set; }
    public string weekDays { get; set; }
    public string monthly { get; set; }
    public string[] currentDay { get; set; }
    public string reportDate { get; set; }
    public string reportTime { get; set; }
    public string reportFormat { get; set; }
    public string statusFlag { get; set; }
    public string reportID { get; set; }
    public string reportableName { get; set; }
    public string assignRole { get; set; }
    public string updateType { get; set; }
    public string QueueId { get; set; }
    public string ServerType { get; set; }
    public string ServerName { get; set; }
    public string FileName { get; set; }

    public string senderMail { get; set; }
    public string mailPassword { get; set; }
    public string smtpserverName { get; set; }
    public string portNumber { get; set; }
    public string tableName { get; set; }
    public int id { get; set; }
    public string filePath { get; set; }

    private DbProviderFactory factory;
    private DbConnection dConn;
    private String connString, providerStr = "";

    public void CreateConnection() //Default Constructor
    {
        XmlTextReader reader = null;
        string filename = "C:\\WindowsService.xml";

        reader = new XmlTextReader(filename);
        reader.WhitespaceHandling = WhitespaceHandling.None;
        while (reader.Read())
        {
            switch (reader.NodeType)
            {
                case XmlNodeType.Element: // The node is an element.
                    tableName = reader.Name;
                    break;
                case XmlNodeType.Text: //Display the text in each element.
                    if (tableName == "cs")
                        ServerName = reader.Value;
                    else if (tableName == "dp")
                        providerStr = reader.Value;
                    else if (tableName == "mail")
                        senderMail = reader.Value;
                    else if (tableName == "pw")
                        mailPassword = reader.Value;
                    else if (tableName == "smtp")
                        smtpserverName = reader.Value;
                    else if (tableName == "port")
                        portNumber = reader.Value;
                    else if (tableName == "fpath")
                        filePath = reader.Value;
                    break;
                case XmlNodeType.EndElement: //Display the end of the element.                        
                    break;
            }
        }

        connString = ServerName;

        factory = DbProviderFactories.GetFactory(providerStr);

        dConn = factory.CreateConnection();

        //set connection string
        dConn.ConnectionString = connString;

        //open the connection
        try
        {
            dConn.Open();
        }
        catch (Exception e)
        {

        }

    }
    public void EmailSend()
    {
        MailMessage mail = new MailMessage();
        SmtpClient SmtpServer = new SmtpClient(smtpserverName);
        mail.From = new MailAddress(senderMail);
        mail.To.Add(emailList);
        mail.Subject = "Report Mail";
        mail.Body = "This is an e-mail message sent automatically by iInterchange Reporting Tool Scheduler activity.  In case of any difficulties to access the enclosed file, please reach out to administrator";
        System.Net.Mail.Attachment attachment;
        attachment = new System.Net.Mail.Attachment(saveLocation);
        mail.Attachments.Add(attachment);
        SmtpServer.Port = int.Parse(portNumber);
        SmtpServer.Credentials = new System.Net.NetworkCredential(senderMail, mailPassword);
        SmtpServer.EnableSsl = true;
        System.Net.ServicePointManager.ServerCertificateValidationCallback = delegate(object s,
                System.Security.Cryptography.X509Certificates.X509Certificate certificate,
                System.Security.Cryptography.X509Certificates.X509Chain chain,
                System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            return true;
        };
        SmtpServer.Send(mail);


    }

    public DataTable runQueue()
    {
        currentTime = DateTime.Now.ToString("hh:mm tt");
        string schedulerQuery = "select * from QUEUE_REPORT where STTS = 'Queue'";
        DataTable dtList = ExecuteSQLQuery(schedulerQuery);

        for (int i = 0; i < dtList.Rows.Count; i++)
        {
            updateType = "q";
            reportID = dtList.Rows[i]["RPRT_ID"].ToString();
            reportFormat = dtList.Rows[i]["RPRT_FRMT"].ToString();
            //statusFlag = dtList.Rows[i]["FLG"].ToString();
            queryBuilder = dtList.Rows[i]["FNL_QRY"].ToString();
            emailList = null;
            QueueId = dtList.Rows[i]["QUE_ID"].ToString();

            if (reportFormat == "excel" || reportFormat == "Excel")
            {
                FileName = dtList.Rows[i]["RPRT_TTL"].ToString() + "_" + DateTime.Now.ToString("dd-MM-yyyy") + "(" + random.Next(0, 9999).ToString() + ").xls";
                saveLocation = filePath + "\\" + FileName;
            }
            else if (reportFormat == "pdf" || reportFormat == "Pdf")
            {
                FileName = dtList.Rows[i]["RPRT_NAM"].ToString() + "_" + DateTime.Now.ToString("dd-MM-yyyy") + "(" + random.Next(0, 9999).ToString() + ").pdf";
                saveLocation = filePath + "\\" + FileName;
            }
            else if (reportFormat == "html" || reportFormat == "Html")
            {
                FileName = dtList.Rows[i]["RPRT_NAM"].ToString() + "_" + DateTime.Now.ToString("dd-MM-yyyy") + "(" + random.Next(0, 9999).ToString() + ").html";
                saveLocation = filePath + "\\" + FileName;
            }

            FileWrite();

        }

        return dtList;
    }

    public DataTable ExportExcel()
    {
        currentTime = DateTime.Now.ToString("hh:mm tt");
        string schedulerQuery = "select SAVD_RPRT.RPRT_Id, SAVD_RPRT.RPRT_NAM,SAVD_RPRT.QRY_STRNG,SAVD_RPRT.ASSN_ROL,SCHLD_RPRTS.RPRT_DT,SCHLD_RPRTS.RPRT_TM,SCHLD_RPRTS.RCRN_TYP,SCHLD_RPRTS.SAVD_LOC,SCHLD_RPRTS.EML_LST,SCHLD_RPRTS.WK_NAM,SCHLD_RPRTS.RPRT_FMRT from SCHLD_RPRTS left join SAVD_RPRT on SCHLD_RPRTS.RPRT_Id=SAVD_RPRT.RPRT_Id";
        DataTable dtList = ExecuteSQLQuery(schedulerQuery);

        for (int i = 0; i < dtList.Rows.Count; i++)
        {
            updateType = "s";
            queryBuilder = dtList.Rows[i]["QRY_STRNG"].ToString();
            emailList = dtList.Rows[i]["EML_LST"].ToString();
            reportFormat = dtList.Rows[i]["RPRT_FMRT"].ToString();
            recurrence = dtList.Rows[i]["RCRN_TYP"].ToString();
            reportDate = dtList.Rows[i]["RPRT_DT"].ToString();
            reportTime = dtList.Rows[i]["RPRT_TM"].ToString();
            currentDay = dtList.Rows[i]["WK_NAM"].ToString().Split(',');
            reportID = dtList.Rows[i]["RPRT_Id"].ToString();
            reportableName = dtList.Rows[i]["RPRT_NAM"].ToString();
            assignRole = dtList.Rows[i]["ASSN_ROL"].ToString();

            if (reportFormat == "excel" || reportFormat == "Excel")
                saveLocation = filePath + "\\" + dtList.Rows[i]["RPRT_NAM"].ToString() + "_" + DateTime.Now.ToString("dd-MM-yyyy") + "(" + random.Next(0, 9999).ToString() + ").xls";
            else if (reportFormat == "pdf" || reportFormat == "Pdf")
                saveLocation = filePath + "\\" + dtList.Rows[i]["RPRT_NAM"].ToString() + "_" + DateTime.Now.ToString("dd-MM-yyyy") + "(" + random.Next(0, 9999).ToString() + ").pdf";
            else if (reportFormat == "html" || reportFormat == "Html")
                saveLocation = filePath + "\\" + dtList.Rows[i]["RPRT_NAM"].ToString() + "_" + DateTime.Now.ToString("dd-MM-yyyy") + "(" + random.Next(0, 9999).ToString() + ").html";


            if (recurrence == "Daily")
            {
                if (currentTime == reportTime)
                {
                    FileWrite();
                }

            }
            if (recurrence == "Weekly")
            {
                if (currentDay.Contains(DateTime.Now.DayOfWeek.ToString()))
                {
                    if (currentTime == reportTime)
                    {
                        FileWrite();
                    }

                }

            }

            if (recurrence == "Monthly")
            {
                if (currentDay.Contains(DateTime.Now.ToString("dd")))
                {
                    if (currentTime == reportTime)
                    {
                        FileWrite();
                    }
                }

            }

        }
        return dtList;

    }

    public void FileWrite()
    {

        DataTable dtExport = ExecuteSQLQuery(queryBuilder);
        gridDetails.DataSource = dtExport;
        gridDetails.DataBind();
        StringWriter sw = new StringWriter();
        HtmlTextWriter htw = new HtmlTextWriter(sw);
        try
        {

            if (reportFormat == "excel" || reportFormat == "html" || reportFormat == "Excel" || reportFormat == "Html")
            {
                gridDetails.RenderControl(htw);
                string renderedGridView = sw.ToString();
                File.WriteAllText(saveLocation, renderedGridView);
            }
            else if (reportFormat == "pdf" || reportFormat == "Pdf")
            {
                //create empty document
                PdfWriter PdfWriter;
                Document ndocument = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
                PdfWriter.GetInstance(ndocument, new FileStream(saveLocation, FileMode.Create));
                ndocument.Open();
                ndocument.Add(new Paragraph("Empty"));
                ndocument.Close();

                //write the pdf document
                string path = Path.Combine(saveLocation);
                HtmlTextWriter hw = new HtmlTextWriter(sw);
                gridDetails.RenderControl(hw);
                dynamic output = new FileStream(path, FileMode.Create);
                StringReader sr = new StringReader(sw.ToString());
                iTextSharp.text.Document pdfDoc = new iTextSharp.text.Document(PageSize.A4, 10f, 10f, 100f, 0f);
                HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
                iTextSharp.text.pdf.PdfWriter.GetInstance(pdfDoc, output);
                pdfDoc.Open();
                htmlparser.Parse(sr);
                pdfDoc.Close();
            }


            if (string.IsNullOrEmpty(emailList) == false)
            {
                EmailSend();
            }

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (updateType == "s")
            {
                string query = "insert into SCHED_LOG_STATUS(RPRT_ID,RPRT_NAM,ASSN_ROL,USR_NAM,RPRT_DT,RPRT_TM,GNRD_DT,GRND_TM,STATUS)";
                query += "values('" + reportID + "','" + reportableName + "','" + assignRole + "','" + "" + "','" + DateTime.Now.ToString("dd-MMM-yyyy") + "','" + reportTime + "','" + DateTime.Now.ToString("dd-MMM-yyyy") + "','" + DateTime.Now.ToString("hh:MM:ss") + "','" + 1 + "')";
                ExecuteNonQuery(query);
            }
            else if (updateType == "q")
            {
                string dt = DateTime.Now.ToString("dd-MMM-yyyy HH:mm:ss");
                string fromdate = DateTime.ParseExact(dt, "dd-MMM-yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture).ToString("dd-MMM-yyyy HH:mm:ss");

                //  string query = "update QUEUE_REPORT set STTS = 'Completed', GNRTD_DT = TO_DATE('" + fromdate + "', 'dd/MON/yyyy hh24:mi:ss'), FL_NAM = '" + FileName + "' where Que_Id = '" + QueueId + "'";
                string query = "update QUEUE_REPORT set STTS = 'Completed', GNRTD_DT = '" + fromdate + "', FL_NAM = '" + FileName + "' where Que_Id = '" + QueueId + "'";
                ExecuteNonQuery(query);
            }

            dConn.Close();
        }


    }
    public DataTable ExecuteSQLQuery(string queryString)
    {
        DataTable dataTable = new DataTable();
        CreateConnection();
        using (dConn)
        {
            DbCommand command = factory.CreateCommand();
            command.CommandText = queryString;
            command.Connection = dConn;
            DbDataAdapter adapter = factory.CreateDataAdapter();
            adapter.SelectCommand = command;
            adapter.Fill(dataTable);
        }
        dConn.Close();
        return dataTable;
    }

    public int ExecuteNonQuery(string sql)
    {

        CreateConnection();
        int result = 0;

        using (dConn)
        {
            DbCommand command = dConn.CreateCommand();

            command.CommandText = sql;
            result = command.ExecuteNonQuery();
        }
        dConn.Close();
        return result;
    }

}
