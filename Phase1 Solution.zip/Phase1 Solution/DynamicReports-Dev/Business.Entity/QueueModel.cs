﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class QueueModel
{
    public string reportNo { get; set; }
    public string reportType { get; set; }
    public string reportName { get; set; }
    public string format { get; set; }
    public string query { get; set; }
    public string priority { get; set; }
    public string fromDate { get; set; }
    public string toDate { get; set; }
    public int flag { get; set; }
    public string Status { get; set; }
}

