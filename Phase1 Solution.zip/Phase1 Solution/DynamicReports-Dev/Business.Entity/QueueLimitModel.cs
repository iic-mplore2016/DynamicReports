﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class QueueLimitModel
{
    public string QueueLimit { get; set; }
    public string AssignTO { get; set; }
    public string UserID { get; set; }
    public string UserName { get; set; }
}
