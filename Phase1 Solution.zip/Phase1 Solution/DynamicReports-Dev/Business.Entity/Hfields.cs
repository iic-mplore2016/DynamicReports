﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

    class Hfields
    {
        public string hnfieldslected { get; set; }
        public string hfslectedval { get; set; }
        public string hddnFields { get; set; }
        public string subhddnFields { get; set; }
    }
