﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


public class TableJoin
{
    public string repId { get; set; }
    public string fieldLeft { get; set; }
    public string joinType { get; set; }
    public string fieldRight { get; set; }
}

