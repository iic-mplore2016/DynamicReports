﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class LookUpColumn
{
    public string LookUpActualColumn { get; set; }
    public string LookUpAliasColumn { get; set; }
}

