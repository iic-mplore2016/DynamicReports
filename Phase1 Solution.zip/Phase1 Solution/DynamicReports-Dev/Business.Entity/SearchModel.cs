﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class SearchModel
{
    public string fromDate { get; set; }
    public string toDate { get; set; }
    public string fromTime { get; set; }
    public string toTime { get; set; }
    public string Status { get; set; }
}

